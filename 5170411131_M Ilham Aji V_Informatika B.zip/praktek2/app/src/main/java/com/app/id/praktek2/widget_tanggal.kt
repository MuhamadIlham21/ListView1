package com.app.id.praktek2

import android.app.DatePickerDialog
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.DatePicker
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_widget_tanggal.*
import java.text.SimpleDateFormat
import java.util.*
import javax.xml.datatype.DatatypeConstants.MONTHS

class widget_tanggal : AppCompatActivity() {

    var edDate: EditText? = null
    var call = Calendar.getInstance()

    lateinit var edt: EditText
    val c = Calendar.getInstance()
    val year = c.get(Calendar.YEAR)
    val month = c.get(Calendar.MONTH)
    val day = c.get(Calendar.DAY_OF_MONTH)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_widget_tanggal)

        edt = findViewById(R.id.editDate) as EditText
        edDate = this.edDate

        edt.setOnClickListener {
            val dpd = DatePickerDialog(this, DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->

                // Display Selected date in textbox
                editDate.setText(dayOfMonth.toString() + "/" + monthOfYear.toString() + "/" + year.toString())
            }, year, month, day)

            dpd.show()
        }


        var valueProdi = arrayOf("Teknik informatika","Sistem Informasi", "Manajemen Informatika", "Teknik Elektro", "Sistem Komputer", "Teknik Sipil", "Arsitektur")

        spJurusan.adapter = ArrayAdapter<String>(
            this@widget_tanggal,
            android.R.layout.simple_spinner_dropdown_item, valueProdi)

    }

}
